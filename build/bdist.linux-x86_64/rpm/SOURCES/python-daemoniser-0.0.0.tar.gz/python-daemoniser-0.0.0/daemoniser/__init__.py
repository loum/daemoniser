"""Support shorthand import of our classes into the namespace.
"""
from daemoniser.daemon import Daemon
from daemoniser.service import Service
